import sys
import os
import os.path
from PIL import Image
import json

root = sys.argv[1]

res = {"providers": []}
char_map = []
i = 0

def findTextures(subdir):
    global i
    for file in sorted(os.listdir(os.path.join(root, subdir))):
        if not file.endswith('.png'):
            continue
        with Image.open(os.path.join(root, subdir, file)) as image:
            if image.size == (16, 16):
                # print(subdir, file, image.size)
                res["providers"].append({
                    "type": "bitmap",
                    "file": f"minecraft:{subdir}/{file}",
                    "ascent": 9,
                    "height": 10,
                    "chars": [
                        f"\\ue{i:03x}"
                    ]
                })
                char_map.append((f"\\ue{i:03x}", bytes(f"\\ue{i:03x}", 'utf-8').decode('unicode_escape') , file.removesuffix('.png')))
                i += 1

findTextures('block')
findTextures('item')

with open(sys.argv[2], 'w', encoding='utf-8') as file:
    file.write(json.dumps(res, indent=4, ensure_ascii=False).replace('\\\\', '\\'))

with open('char-map.txt', 'w', encoding='utf-8') as file:
    for uni, ch, tex in char_map:
        file.write(f"{uni}\t{ch}\t{tex}\n")